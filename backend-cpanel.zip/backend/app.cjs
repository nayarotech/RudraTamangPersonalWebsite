// cPanel "Setup Node.js App" startup file. Passenger loads this; it starts the
// compiled ES-module server, which listens on the port Passenger provides.
import("./dist/server.js").catch((err) => {
  console.error(err);
  process.exit(1);
});
